/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_478()
{
    return 1187221848U;
}

unsigned addval_333(unsigned x)
{
    return x + 2027307002U;
}

unsigned getval_131()
{
    return 3284633928U;
}

void setval_327(unsigned *p)
{
    *p = 2428995912U;
}

unsigned getval_144()
{
    return 2425379070U;
}

unsigned getval_230()
{
    return 3284633920U;
}

unsigned addval_112(unsigned x)
{
    return x + 3267856712U;
}

unsigned getval_429()
{
    return 3116601432U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_296()
{
    return 1170719369U;
}

void setval_329(unsigned *p)
{
    *p = 2430634312U;
}

unsigned getval_199()
{
    return 3232026249U;
}

unsigned addval_177(unsigned x)
{
    return x + 3531129481U;
}

unsigned getval_379()
{
    return 3286272072U;
}

void setval_453(unsigned *p)
{
    *p = 2496760085U;
}

unsigned getval_213()
{
    return 3525365385U;
}

unsigned getval_175()
{
    return 3682913933U;
}

void setval_212(unsigned *p)
{
    *p = 3221279113U;
}

unsigned getval_393()
{
    return 3532968329U;
}

unsigned getval_148()
{
    return 3223896713U;
}

void setval_232(unsigned *p)
{
    *p = 3286280520U;
}

unsigned addval_497(unsigned x)
{
    return x + 3767093319U;
}

unsigned addval_143(unsigned x)
{
    return x + 3348156041U;
}

unsigned addval_305(unsigned x)
{
    return x + 3676885385U;
}

void setval_336(unsigned *p)
{
    *p = 3385118345U;
}

unsigned addval_202(unsigned x)
{
    return x + 3229926025U;
}

unsigned getval_456()
{
    return 3353381192U;
}

void setval_413(unsigned *p)
{
    *p = 3224948361U;
}

void setval_275(unsigned *p)
{
    *p = 3677933961U;
}

void setval_154(unsigned *p)
{
    *p = 3234120329U;
}

unsigned addval_284(unsigned x)
{
    return x + 3378564745U;
}

unsigned addval_472(unsigned x)
{
    return x + 2425537161U;
}

unsigned getval_494()
{
    return 3380137609U;
}

void setval_335(unsigned *p)
{
    *p = 2497743176U;
}

void setval_389(unsigned *p)
{
    *p = 3680551561U;
}

void setval_399(unsigned *p)
{
    *p = 2430634344U;
}

void setval_243(unsigned *p)
{
    *p = 2428668273U;
}

unsigned addval_208(unsigned x)
{
    return x + 3251734785U;
}

unsigned addval_499(unsigned x)
{
    return x + 3678982537U;
}

void setval_130(unsigned *p)
{
    *p = 3374371209U;
}

unsigned getval_318()
{
    return 3353381192U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
